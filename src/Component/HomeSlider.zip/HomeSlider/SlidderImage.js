import First from "../../imgs/img1.jpeg";
import Second from "../../imgs/img1.jpeg";
import Third from "../../imgs/img1.jpeg";

export default [
  {
    title: "First Slide",
    description: "The New Delivery Service Company Stock Is Rising And Never Going Down",
    urls: First,
  },
  {
    title: "Second Slide",
    description: "The New Delivery Service Company Stock Is Rising And Never Going Down",
    urls: Second,
  },
  {
    title: "Third Slide",
    description: "The New Delivery Service Company Stock Is Rising And Never Going Down",
    urls: Third,
  },
  {
    title: "Fourth Slide",
    description: "The New Delivery Service Company Stock Is Rising And Never Going Down",
    urls: "https://mdbootstrap.com/img/Photos/Slides/img%20(133).jpg",
  },
  {
    title: "Fifth Slide",
    description: "The New Delivery Service Company Stock Is Rising And Never Going Down",
    urls: "https://mdbootstrap.com/img/Photos/Slides/img%20(147).jpg",
  },
  {
    title: "Sixth Slide",
    description: "The New Delivery Service Company Stock Is Rising And Never Going Down",
    urls: "https://mdbootstrap.com/img/Photos/Slides/img%20(105).jpg",
  },
  {
    title: "Seventh Slide",
    description: "The New Delivery Service Company Stock Is Rising And Never Going Down",
    urls: "https://mdbootstrap.com/img/Photos/Slides/img%20(102).jpg",
  },
];
